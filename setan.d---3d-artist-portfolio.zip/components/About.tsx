import React from 'react';
import { GlassCard } from './UI/GlassCard';
import { SKILLS } from '../constants';
import { motion } from 'framer-motion';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-12 md:py-24 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Bio Side */}
          <div className="relative z-20">
            <motion.h3 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-brand-accent font-mono mb-4"
            >
              // ABOUT_ME
            </motion.h3>
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="font-display text-4xl md:text-5xl font-bold text-white mb-6"
            >
              Building My Path in <br/>
              <span className="text-white/50">3D Design</span>
            </motion.h2>
            <GlassCard className="p-8">
              <p className="text-gray-300 leading-relaxed mb-6">
                Hi, I'm Setan.D. I am currently working as a 3D Artist at <strong>JoyFlux LLP</strong>.
              </p>
              <p className="text-gray-300 leading-relaxed">
                I'm just getting started in this field. My main focus right now is using Blender to model simple objects and give them life with colors and textures. I am constantly learning and practicing to improve my skills every day.
              </p>
            </GlassCard>
          </div>

          {/* Skills Side */}
          <div className="space-y-4 relative z-10">
             <h3 className="text-xl font-display text-white mb-6 md:text-left">My Skills</h3>
             {SKILLS.map((skill, index) => (
               <div key={skill.name} className="relative">
                 <div className="flex justify-between mb-1">
                   <span className="text-sm font-medium text-gray-300">{skill.name}</span>
                 </div>
                 <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden backdrop-blur-sm">
                   <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.2, delay: index * 0.1, ease: "easeOut" }}
                      className="bg-gradient-to-r from-brand-accent to-brand-purple h-2 rounded-full"
                   />
                 </div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </section>
  );
};