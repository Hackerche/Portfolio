import React, { useState, useEffect } from 'react';
import { motion, useScroll, useMotionValueEvent } from 'framer-motion';
import { SectionId } from '../../types';

export const Navbar: React.FC = () => {
  const [hidden, setHidden] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious() || 0;
    if (latest > previous && latest > 150) {
      setHidden(true);
    } else {
      setHidden(false);
    }
  });

  const links = [
    { id: SectionId.HERO, label: 'Home' },
    { id: SectionId.ABOUT, label: 'About' },
    { id: SectionId.PORTFOLIO, label: 'Work' },
    { id: SectionId.SERVICES, label: 'Services' },
    { id: SectionId.CONTACT, label: 'Contact' },
  ];

  return (
    <motion.nav
      variants={{
        visible: { y: 0 },
        hidden: { y: -100 },
      }}
      animate={hidden ? "hidden" : "visible"}
      transition={{ duration: 0.35, ease: "easeInOut" }}
      className="fixed top-0 left-0 right-0 z-50 flex justify-center pt-6 px-4"
    >
      <div className="backdrop-blur-xl bg-black/50 border border-white/10 rounded-full px-6 py-3 shadow-2xl flex gap-8 items-center">
        {links.map((link) => (
          <a
            key={link.id}
            href={`#${link.id}`}
            className="text-sm font-medium text-gray-400 hover:text-white transition-colors relative group"
          >
            {link.label}
            <span className="absolute -bottom-1 left-0 w-0 h-px bg-brand-accent group-hover:w-full transition-all duration-300" />
          </a>
        ))}
      </div>
    </motion.nav>
  );
};