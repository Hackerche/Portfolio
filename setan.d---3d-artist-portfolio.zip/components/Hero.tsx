import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { ARTIST_NAME, TAGLINE } from '../constants';

export const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden z-10">
      {/* Background Gradient Spotlights */}
      <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-brand-accent/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] bg-brand-purple/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6 text-center z-20">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "circOut" }}
          className="mb-6"
        >
          <h2 className="text-brand-accent tracking-[0.2em] text-sm md:text-base font-medium mb-4 uppercase">
            {ARTIST_NAME}
          </h2>
          <h1 className="font-display text-5xl md:text-8xl font-bold leading-tight md:leading-none mix-blend-normal">
            <span className="block text-white">MODEL.</span>
            <span className="block text-white/50">COLOR.</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-brand-purple">
              CREATE.
            </span>
          </h1>
        </motion.div>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mt-6 font-light"
        >
          {TAGLINE}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-12 flex flex-col md:flex-row gap-6 justify-center items-center"
        >
          <a 
            href="#work"
            className="group relative px-8 py-4 bg-white text-black font-semibold rounded-full overflow-hidden transition-all hover:scale-105"
          >
            <div className="absolute inset-0 w-full h-full bg-brand-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300 mix-blend-darken" />
            <span className="relative z-10">My Work</span>
          </a>
          <a 
            href="#contact"
            className="px-8 py-4 border border-white/20 text-white font-medium rounded-full hover:bg-white/10 transition-all hover:border-white/40 backdrop-blur-md"
          >
            Contact Me
          </a>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce text-white/30"
      >
        <ArrowDown size={24} />
      </motion.div>
    </section>
  );
};