import React, { useState } from 'react';
import { GlassCard } from './UI/GlassCard';
import { generateAIResponse } from '../services/geminiService';
import { Send, Sparkles, Loader2, Mail, Instagram, Linkedin, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';

export const Contact: React.FC = () => {
  // Contact Form State
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // AI Chat State
  const [aiInput, setAiInput] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiThinking, setIsAiThinking] = useState(false);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitStatus('success');
      setFormState({ name: '', email: '', message: '' });
    }, 1500);
  };

  const handleAiAsk = async () => {
    if (!aiInput.trim()) return;
    
    setIsAiThinking(true);
    setAiResponse(null);
    
    const response = await generateAIResponse(aiInput);
    
    setAiResponse(response);
    setIsAiThinking(false);
  };

  return (
    <section id="contact" className="py-24 relative z-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Contact Form */}
          <div>
            <motion.div
               initial={{ opacity: 0, x: -20 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl font-bold text-white mb-2">Let's Create Together</h2>
              <p className="text-gray-400 mb-8">Available for freelance projects and studio collaborations.</p>
            </motion.div>
            
            <GlassCard className="p-8">
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                  <input 
                    type="text" 
                    required
                    value={formState.name}
                    onChange={e => setFormState({...formState, name: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent transition-all"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                  <input 
                    type="email" 
                    required
                    value={formState.email}
                    onChange={e => setFormState({...formState, email: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent transition-all"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Message</label>
                  <textarea 
                    rows={4}
                    required
                    value={formState.message}
                    onChange={e => setFormState({...formState, message: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-accent focus:ring-1 focus:ring-brand-accent transition-all"
                    placeholder="Tell me about your project..."
                  />
                </div>
                
                <button 
                  type="submit" 
                  disabled={isSubmitting || submitStatus === 'success'}
                  className="w-full py-4 bg-brand-accent text-black font-bold rounded-lg hover:bg-cyan-300 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="animate-spin" /> : <Send size={18} />}
                  {submitStatus === 'success' ? 'Message Sent!' : 'Send Message'}
                </button>
              </form>
            </GlassCard>

            <div className="flex gap-4 mt-8 justify-center lg:justify-start">
              {[Mail, Instagram, Linkedin, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="p-3 bg-white/5 rounded-full hover:bg-brand-accent hover:text-black transition-all text-white border border-white/10">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* AI Assistant Side */}
          <div className="lg:mt-16">
            <GlassCard className="p-1 h-full min-h-[400px] flex flex-col bg-gradient-to-br from-brand-purple/20 to-transparent">
              <div className="flex-1 p-8 flex flex-col justify-center">
                 <div className="mb-6 flex items-center gap-3">
                    <div className="p-2 bg-brand-purple rounded-lg">
                      <Sparkles className="text-white" size={24} />
                    </div>
                    <div>
                      <h3 className="text-white font-bold text-lg">Lumina AI</h3>
                      <p className="text-xs text-gray-400">Powered by Gemini 2.5</p>
                    </div>
                 </div>

                 <p className="text-gray-300 mb-6">
                   Curious about my workflow, availability, or favorite tools? Ask my AI assistant instantly.
                 </p>

                 <div className="relative">
                   <div className="flex gap-2">
                     <input 
                        type="text" 
                        value={aiInput}
                        onChange={(e) => setAiInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAiAsk()}
                        placeholder="e.g., What software do you use?"
                        className="flex-1 bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-purple transition-all"
                     />
                     <button 
                        onClick={handleAiAsk}
                        disabled={isAiThinking}
                        className="px-4 bg-brand-purple text-white rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50"
                     >
                       {isAiThinking ? <Loader2 className="animate-spin" /> : <Send size={18} />}
                     </button>
                   </div>
                 </div>

                 {/* Response Area */}
                 <div className="mt-6 min-h-[100px] bg-black/20 rounded-lg p-4 border border-white/5">
                    {isAiThinking ? (
                      <div className="flex gap-2 items-center text-gray-500 text-sm">
                        <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce delay-75"></span>
                        <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce delay-150"></span>
                        Thinking...
                      </div>
                    ) : aiResponse ? (
                      <motion.p 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }}
                        className="text-gray-200 text-sm leading-relaxed"
                      >
                        "{aiResponse}"
                      </motion.p>
                    ) : (
                      <p className="text-gray-600 text-sm italic">Response will appear here...</p>
                    )}
                 </div>
              </div>
            </GlassCard>
          </div>

        </div>
      </div>
    </section>
  );
};