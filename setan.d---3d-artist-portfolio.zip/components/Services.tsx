import React from 'react';
import { GlassCard } from './UI/GlassCard';
import { SERVICES } from '../constants';
import { Box, Layers, Zap, Monitor } from 'lucide-react';
import { motion } from 'framer-motion';

const iconMap = {
  Box: Box,
  Layers: Layers,
  Zap: Zap,
  Monitor: Monitor
};

export const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 relative z-10">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h3 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-brand-purple font-mono mb-2"
          >
            // EXPERTISE
          </motion.h3>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl md:text-5xl font-bold text-white"
          >
            Capabilities
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service, index) => {
            const Icon = iconMap[service.iconName];
            return (
              <GlassCard 
                key={service.id} 
                className="p-8 group" 
                hoverEffect={true} 
                delay={index * 0.1}
              >
                <div className="mb-6 p-4 rounded-xl bg-white/5 w-fit group-hover:bg-brand-accent/20 transition-colors duration-300">
                  <Icon className="text-brand-accent group-hover:text-white transition-colors duration-300" size={32} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 font-display">{service.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {service.description}
                </p>
              </GlassCard>
            );
          })}
        </div>
      </div>
    </section>
  );
};