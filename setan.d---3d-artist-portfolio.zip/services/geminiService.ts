import { GoogleGenAI } from "@google/genai";
import { ARTIST_NAME, PROJECTS, SERVICES, SKILLS } from '../constants';

const API_KEY = process.env.API_KEY || '';

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

export const generateAIResponse = async (userMessage: string): Promise<string> => {
  if (!ai) {
    return "AI services are currently offline. Please contact me directly via email.";
  }

  const systemPrompt = `
    You are the AI Assistant for ${ARTIST_NAME}'s portfolio website.
    Your persona is professional, creative, and slightly futuristic.
    
    Here is the context about the artist:
    Skills: ${SKILLS.map(s => s.name).join(', ')}.
    Services: ${SERVICES.map(s => s.title).join(', ')}.
    Recent Projects: ${PROJECTS.map(p => p.title).join(', ')}.
    
    Your goal is to answer visitor questions about the artist's work, availability, and technical expertise.
    Keep answers concise (under 50 words unless asked for detail).
    If asked about pricing, suggest using the contact form for a custom quote.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userMessage,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    return response.text || "I processed that, but couldn't generate a text response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to the neural network right now. Please try again later.";
  }
};